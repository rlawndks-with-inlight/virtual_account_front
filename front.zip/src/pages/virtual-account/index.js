import VirtualAccountAddNoneAuth from "./[mid]";

export default VirtualAccountAddNoneAuth;