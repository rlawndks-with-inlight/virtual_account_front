import VirtualAccountAddNoneAuth from "./[id]";

export default VirtualAccountAddNoneAuth;