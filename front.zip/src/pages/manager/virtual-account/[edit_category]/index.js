import VirtualAccountEdit from "./[id]";
export default VirtualAccountEdit
