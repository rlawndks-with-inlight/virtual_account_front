import MotherAccountEdit from "./[id]";
export default MotherAccountEdit
