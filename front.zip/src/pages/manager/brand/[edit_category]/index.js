import BrandEdit from "./[id]";
export default BrandEdit
