import UserEdit from "./[id]";
export default UserEdit
