import DepositAccountEdit from "./[id]";
export default DepositAccountEdit;