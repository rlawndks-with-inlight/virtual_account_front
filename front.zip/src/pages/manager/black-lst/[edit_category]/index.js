import BlackListEdit from "./[id]";
export default BlackListEdit
