import CorpAccountEdit from "./[id]";
export default CorpAccountEdit
