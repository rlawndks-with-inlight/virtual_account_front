
const Bell = () => {
    return (
        <>
            <audio autoPlay={true} src={'/assets/sound/bell.mp3'} />
        </>
    )
}
export default Bell;