export * from './config-lang';

export { default as useLocales } from './useLocales';

export { default } from './ThemeLocalization';
