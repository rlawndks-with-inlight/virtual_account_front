export { default } from './ManagerLayout';
