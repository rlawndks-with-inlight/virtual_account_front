
export const COLUMNS = {
  cart:{

  },
  item:{

  },
  user:{

  },
}
