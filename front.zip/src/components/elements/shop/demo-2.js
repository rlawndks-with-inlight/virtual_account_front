//자주쓰는 컴포넌트 저장하는 곳 박이규

import styled from "styled-components";

const Wrappers = styled.div`
max-width: 1200px;
display: flex;
flex-direction: column;
margin: 0 auto;
width: 90%;
min-height: 90vh;
margin-bottom: 10vh;
`

// 박이규
export const Demo2 = (props) => {
    const {
        data: {

        },
        func: {
            router
        },
    } = props;
    return (
        <>

        </>
    )
}
export const Item = (props) =>{

    return (
        <>
        
        </>
    )
}