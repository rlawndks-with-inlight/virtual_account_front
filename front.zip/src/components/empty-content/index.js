export { default } from './EmptyContent';
