export { default } from './Image';
